﻿"use strict";

// CONSTANTS THAT ARE VARIABLES BASICALLY

const leftpanelwidth = 50 // Size of left panel
const miniwidth = 500
const miniheight = 189

var storedwidth = 1920
var storedheight = 1080

// SETTING UP TAB SWITCHER

let ww = 0;
let wh = 0;
let g_backcolour = 0xFF191919;

var isMini = false
var curPanelName = ""

let allpanelnames = getAllPanelNames();
let subpanelnames = getMainPanelNames()
let mininames = getMiniPanelNames();

let subpanels = [];

for (let pn of allpanelnames) {
    subpanels.push(window.GetPanel(pn));
    }


let deltaheight = 0;

function getAllPanelNames(max = 50) {
	let names = [];

	for (let i = 0; i < max; i++) {
	try {
		const panel = window.GetPanelByIndex(i);

		if (panel == null) break;

		// Guard against missing Name property
		if (panel.Name != null) {
		names.push(panel.Text);
		}
	} catch (e) {
		break;
	}
	}

	names.sort()
	return names;
}

function getMainPanelNames() {
	let mainnames = []

	for (let n of getAllPanelNames()) {
		if (n.indexOf('MINI') == -1) {
			mainnames.push(n)
		}
	}
	return mainnames
}

function getMiniPanelNames() {
	let mininames = []

	for (let n of getAllPanelNames()) {
		if (n.indexOf('MINI') > -1) {
			mininames.push(n)
		}
	}
	return mininames
}


function switch_to(panel) {
    for (let subpanel of subpanels) {
    subpanel.Hidden = true;
    }

    panel.Hidden = false;
}

// SETTING UP BUTTON PANELS

include(fb.ComponentPath + 'samples\\complete\\js\\lodash.min.js');
include(fb.ComponentPath + 'samples\\complete\\js\\helpers.js');

let panel = new _panel(true);
let buttons = new _buttons();
let bs = 50;
let vs = 20;

let imagePath = utils.GetPackageInfo(window.ScriptInfo.PackageId).Directories.Assets
let iconimagepath = imagePath
let divimg = gdi.Image(imagePath + '\\Divider.png')

function call_switch(panelname) {
	if (panelname == curPanelName) {
		return
	}
    switch_to(window.GetPanel(panelname))
	curPanelName = panelname
    panelname = null;
	buttons.update();
	window.Repaint();
}

function newButton(x, y, pname) {
	let fname = pname.split("_")[1];
	let curPanelShort = curPanelName.split("_")[1];

	let fnambase = imagePath+'\\buttons\\'+fname
	if (!utils.FileExists(fnambase+'.png')) {
		fnambase = imagePath+'\\buttons\\'+"Default"
	}

	return new _button(x, y, bs, bs, {normal : curPanelShort != fname ? fnambase+'.png' : fnambase+'Active.png', 
											hover : curPanelShort != fname ? fnambase+'Hover.png' : fnambase+'HoverActive.png'}, 
											(x, y) => { call_switch(pname); }, '');
}

function toggle_mini() {
	isMini = !isMini;

	buttons.update();
	
	if (isMini) {
		call_switch(mininames[0]);
		storedwidth = window.FoobarWindowWidth
		storedheight = window.FoobarWindowHeight 
		window.FoobarWindowWidth = miniwidth
		window.FoobarWindowHeight = miniheight

	} else {
		call_switch(subpanelnames[0]);
		window.FoobarWindowWidth = storedwidth
		window.FoobarWindowHeight = storedheight
	}

}


buttons.update = () => {
	if (!isMini) {
		buttons.buttons.menu =      new _button(0, 0, bs, bs, {normal : imagePath + '\\MainMenu.png', hover : imagePath + '\\MainMenuHover.png'}, (x, y, mask) => { _menu(0, 0); }, '');

		for (let i = 0; i < subpanelnames.length; i++){
			buttons.buttons[subpanelnames[i]] = newButton(0, vs+bs*(i+1), subpanelnames[i]);
		};
		for (let n of mininames){
			buttons.buttons[n] = newButton(-100, 0, n);
		};

		if (true) {
			buttons.buttons.mini =      new _button(0, wh-2*bs, bs, bs, {normal : imagePath + '\\MINI.png', hover : imagePath + '\\MINIHover.png'}, (x, y, mask) => {toggle_mini(); }, '');
		}


		buttons.buttons.settings =      new _button(0, wh-bs, bs, bs, {normal : imagePath + '\\Settings.png', hover : imagePath + '\\SettingsHover.png'}, (x, y, mask) => { fb.ShowPreferences(); }, '');
	} else {
		buttons.buttons.mini =      new _button(0, 0, bs, bs, {normal : imagePath + '\\MAXI.png', hover : imagePath + '\\MAXIHover.png'}, (x, y, mask) => {toggle_mini(); }, '');
		
		for (let i = 0; i < mininames.length; i++){
			buttons.buttons[mininames[i]] = newButton(0, bs*(i+1), mininames[i]);
		};

		
		for (let n of subpanelnames){
			buttons.buttons[n] = newButton(-100, 0, n);
		};
		buttons.buttons.menu =      new _button(-100, 0, bs, bs, {normal : imagePath + '\\MainMenu.png', hover : imagePath + '\\MainMenuHover.png'}, (x, y, mask) => { _menu(0, 0); }, '');
		buttons.buttons.settings =      new _button(-100, 0, bs, bs, {normal : imagePath + '\\Settings.png', hover : imagePath + '\\SettingsHover.png'}, (x, y, mask) => { fb.ShowPreferences(); }, '');

	}

}



// on event functions

function on_size(width, height) {

    ww = width;
    wh = height;

    for (let subpanel of subpanels) {
    subpanel.Move(leftpanelwidth, 0, width-leftpanelwidth, height)
    }

    panel.size();
    buttons.update();

}

function on_paint(gr) {
    gr.FillSolidRect(0, 0, ww, wh, g_backcolour);
    panel.paint(gr);
    buttons.paint(gr);
	if (!isMini) {
		gr.DrawImage(divimg, 0, bs-5, bs, vs, 0, 0, 100, 40);
	}
}

function on_mouse_move(x, y) {
	buttons.move(x, y);
}

function on_mouse_leave() {
	buttons.leave();
}

function on_mouse_lbtn_up(x, y, mask) {
	buttons.lbtn_up(x, y, mask);
}

function on_mouse_rbtn_up(x, y) {
	return panel.rbtn_up(x, y);
}

function on_colours_changed() {
	panel.colours_changed();
	window.Repaint();
}



// Panel function taken from panel.js (has been modified)
function _panel(custom_background = false) {
	this.item_focus_change = () => {
		if (this.metadb_func) {
			if (this.selection.value == 0) {
				this.metadb = fb.IsPlaying ? fb.GetNowPlaying() : fb.GetFocusItem();
			} else {
				this.metadb = fb.GetFocusItem();
			}
			on_metadb_changed();
			if (!this.metadb) {
				_tt('');
			}
		}
	}

	this.colours_changed = () => {
		if (window.InstanceType) {
			this.colours.background = window.GetColourDUI(1);
			this.colours.text = window.GetColourDUI(0);
			this.colours.highlight = window.GetColourDUI(2);
		} else {
			this.colours.background = window.GetColourCUI(3);
			this.colours.text = window.GetColourCUI(0);
			this.colours.highlight = _blendColours(this.colours.text, this.colours.background, 0.4);
		}
		this.colours.header = this.colours.highlight & 0x45FFFFFF;
	}

	this.font_changed = () => {
		let name;
		let font = window.InstanceType ? window.GetFontDUI(0) : window.GetFontCUI(0);
		if (font) {
			name = font.Name;
		} else {
			name = 'Segoe UI';
			console.log(N, 'Unable to use default font. Using', name, 'instead.');
		}
		this.fonts.title = _gdiFont(name, 12, 1);
		this.fonts.normal = _gdiFont(name, this.fonts.size.value);
		this.fonts.fixed = _gdiFont('Lucida Console', this.fonts.size.value);
		this.row_height = this.fonts.normal.Height;
		_.invokeMap(this.list_objects, 'size');
		_.invokeMap(this.list_objects, 'update');
		_.invokeMap(this.text_objects, 'size');
	}

	this.size = () => {
		this.w = leftpanelwidth;
		this.h = window.Height;
	}

	this.paint = (gr) => {
		let col;
		switch (true) {
		case window.IsTransparent:
			return;
		case !this.custom_background:
		case this.colours.mode.value == 0:
			col = this.colours.background;
			break;
		case this.colours.mode.value == 1:
			col = utils.GetSysColour(15);
			break;
		case this.colours.mode.value == 2:
			col = this.colours.custom_background.value;
			break;
		}
		gr.FillSolidRect(0, 0, this.w, this.h, col);
	}

	this.rbtn_up = (x, y, object) => {
		this.m = window.CreatePopupMenu();
		this.s1 = window.CreatePopupMenu();
		this.s2 = window.CreatePopupMenu();
		this.s3 = window.CreatePopupMenu();
		this.s10 = window.CreatePopupMenu();
		this.s11 = window.CreatePopupMenu();
		this.s12 = window.CreatePopupMenu();
		this.s13 = window.CreatePopupMenu();
		// panel 1-999
		// object 1000+
		if (object) {
			object.rbtn_up(x, y);
		}
		if (this.list_objects.length || this.text_objects.length) {
			_.forEach(this.fonts.sizes, (item) => {
				this.s1.AppendMenuItem(MF_STRING, item, item);
			});
			this.s1.CheckMenuRadioItem(_.first(this.fonts.sizes), _.last(this.fonts.sizes), this.fonts.size.value);
			this.s1.AppendTo(this.m, MF_STRING, 'Font size');
			this.m.AppendMenuSeparator();
		}
		if (this.custom_background) {
			this.s2.AppendMenuItem(MF_STRING, 100, window.InstanceType ? 'Use default UI setting' : 'Use columns UI setting');
			this.s2.AppendMenuItem(MF_STRING, 101, 'Splitter');
			this.s2.AppendMenuItem(MF_STRING, 102, 'Custom');
			this.s2.CheckMenuRadioItem(100, 102, this.colours.mode.value + 100);
			this.s2.AppendMenuSeparator();
			this.s2.AppendMenuItem(this.colours.mode.value == 2 ? MF_STRING : MF_GRAYED, 103, 'Set custom colour...');
			this.s2.AppendTo(this.m, window.IsTransparent ? MF_GRAYED : MF_STRING, 'Background');
			this.m.AppendMenuSeparator();
		}
		if (this.metadb_func) {
			this.s3.AppendMenuItem(MF_STRING, 110, 'Prefer now playing');
			this.s3.AppendMenuItem(MF_STRING, 111, 'Follow selected track (playlist)');
			this.s3.CheckMenuRadioItem(110, 111, this.selection.value + 110);
			this.s3.AppendTo(this.m, MF_STRING, 'Selection mode');
			this.m.AppendMenuSeparator();
		}
		this.m.AppendMenuItem(MF_STRING, 120, 'Configure...');
		const idx = this.m.TrackPopupMenu(x, y);
		switch (true) {
		case idx == 0:
			break;
		case idx <= 20:
			this.fonts.size.value = idx;
			this.font_changed();
			window.Repaint();
			break;
		case idx == 100:
		case idx == 101:
		case idx == 102:
			this.colours.mode.value = idx - 100;
			window.Repaint();
			break;
		case idx == 103:
			this.colours.custom_background.value = utils.ColourPicker(window.ID, this.colours.custom_background.value);
			window.Repaint();
			break;
		case idx == 110:
		case idx == 111:
			this.selection.value = idx - 110;
			this.item_focus_change();
			break;
		case idx == 120:
			window.ShowConfigure();
			break;
		case idx > 999:
			if (object) {
				object.rbtn_up_done(idx);
			}
			break;
		}
		return true;
	}

	this.tf = (t) => {
		if (!this.metadb) {
			return '';
		}
		if (!this.tfo[t]) {
			this.tfo[t] = fb.TitleFormat(t);
		}
		const path = this.tfo['$if2(%__@%,%path%)'].EvalWithMetadb(this.metadb);
		if (fb.IsPlaying && (path.startsWith('http') || path.startsWith('mms'))) {
			return this.tfo[t].Eval();
		} else {
			return this.tfo[t].EvalWithMetadb(this.metadb);
		}
	}

	window.DlgCode = DLGC_WANTALLKEYS;
	this.fonts = {};
	this.colours = {};
	this.w = 0;
	this.h = 0;
	this.metadb = fb.GetFocusItem();
	this.metadb_func = typeof on_metadb_changed == 'function';
	this.fonts.sizes = [10, 12, 14, 16];
	this.fonts.size = new _p('2K3.PANEL.FONTS.SIZE', 12);
	if (this.metadb_func) {
		this.selection = new _p('2K3.PANEL.SELECTION', 0);
	}
	if (custom_background) {
		this.custom_background = true;
		this.colours.mode = new _p('2K3.PANEL.COLOURS.MODE', 0);
		this.colours.custom_background = new _p('2K3.PANEL.COLOURS.CUSTOM.BACKGROUND', _RGB(0, 0, 0));
	} else {
		this.custom_background = false;
	}
	this.list_objects = [];
	this.text_objects = [];
	this.tfo = {
		'$if2(%__@%,%path%)' : fb.TitleFormat('$if2(%__@%,%path%)')
	};
	this.font_changed();
	this.colours_changed();
}

call_switch(subpanelnames[0]);