﻿"use strict";

let scriptpath = utils.GetPackageInfo(window.ScriptInfo.PackageId).Directories.Scripts

// window.DefinePanel("JS Smooth Browser", { author : "Br3tt aka Falstaff" });
include(scriptpath + "\\JScommon.js");
include(scriptpath + "\\JSinputbox.js");
include(scriptpath + "\\jssp.js");