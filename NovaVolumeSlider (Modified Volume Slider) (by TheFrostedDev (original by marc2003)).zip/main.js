﻿'use strict';

// Modified Volume Slider Script, original by marc2003
// (modified by TheFrostedDev)

// window.DefineScript('Volume Slider', {author:'marc2003', options:{grab_focus:false}});
include(fb.ComponentPath + 'samples\\complete\\js\\lodash.min.js');
include(fb.ComponentPath + 'samples\\complete\\js\\helpers.js');
include(fb.ComponentPath + 'samples\\complete\\js\\volume.js');

let volume = new _volume(0, 0, 0, 0);
volume.c1 = _RGB(121, 121, 121);
volume.c2 = _RGB(255, 255, 255);

let padX = 5
let padY = 10
let totalBG = _RGB(25, 25, 25)

function on_mouse_lbtn_down(x, y) {
	volume.lbtn_down(x, y);
}

function on_mouse_lbtn_up(x, y) {
	volume.lbtn_up(x, y);
}

function on_mouse_move(x, y) {
	volume.move(x, y);
}

function on_mouse_wheel(s) {
	volume.wheel(s);
}

// function on_paint(gr) {
// 	gr.FillSolidRect(volume.x, volume.y, volume.w, volume.h, volume.c1);
// 	gr.SetSmoothingMode(2);
// 	let points = [volume.x, volume.y + volume.h, volume.x + volume.pos(), volume.y + volume.h, volume.x + volume.pos(), volume.y + volume.h - volume.pos('h')];
// 	gr.FillPolygon(volume.c2, 1, points);
// }

function on_paint(gr) {
    gr.SetSmoothingMode(2); // Anti-aliasing for smooth edges

    // Slider dimensions, colors, and padding
    let x = volume.x + padX; // horizontal padding
    let y = volume.y + padY; // vertical padding
    let w = volume.w - 2 * padX; // adjusted width
    let h = volume.h - 2 * padY; // adjusted height
    let radius = Math.floor(h / 2); // Half-height for pill ends

    let bgColor = volume.c1; // Background color
    let fillColor = volume.c2; // Filled portion color

    gr.FillSolidRect(volume.x-25, volume.y-25, volume.w+50, volume.h+50, totalBG)

    // Draw background slider (pill shape)
    gr.FillSolidRect(x + radius, y, w - 2 * radius, h, bgColor); // center rectangle
    gr.FillEllipse(x, y, h, h, bgColor); // left end
    gr.FillEllipse(x + w - h, y, h, h, bgColor); // right end

    // Draw filled portion
    let filledWidth = Math.min(volume.pos(), w); // clamp filled width

    if (filledWidth > 0) {
        if (filledWidth <= radius) {
            // Small values: only left end
            gr.FillEllipse(x, y, filledWidth * 2, h, fillColor);
        } else if (filledWidth < w - radius) {
            // Left circle + rectangle
            gr.FillEllipse(x, y, h, h, fillColor);
            gr.FillSolidRect(x + radius, y, filledWidth - radius, h, fillColor);
        } else {
            // Fill full pill
            gr.FillSolidRect(x + radius, y, w - 2 * radius, h, fillColor);
            gr.FillEllipse(x, y, h, h, fillColor);
            gr.FillEllipse(x + w - h, y, h, h, fillColor);
        }
    }
}

function on_size() {
	volume.w = window.Width;
	volume.h = window.Height;
}

function on_volume_change() {
	volume.volume_change();
}
